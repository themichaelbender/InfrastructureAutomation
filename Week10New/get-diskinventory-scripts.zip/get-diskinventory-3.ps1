﻿#get-diskinventory-3.ps1
#Listing 21.2

#Create a Parametized Script
#Allowing parameter value input when runnig script

#Create a parameter block for computername where localhost is default
param (
        $computername = 'localhost'
)
    Get-WmiObject -Class Win32_LogicalDisk `
        -ComputerName $computername `
        -Filter "drivetype=3" |
    Sort-Object -Property DeviceID |
    Format-Table -Property DeviceID,
    @{label='FreeSpace(MB)';expression={$_.Freespace / 1MB -as [int]}},
    @{label='Size(GB)';expression={$_.Size / 1GB -as [int]}},
    @{Label='%Free';expression={$_.FreeSpace /$_.Size * 100 -as [int]}}