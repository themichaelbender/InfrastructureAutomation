﻿#get-diskinventory-2.ps1
#Listing 21.1

    #Using Variables
    #Using Variable for computername
    #Use Backtick for better readability
    $computername = 'localhost'
        Get-WmiObject -Class Win32_LogicalDisk `
            -ComputerName $computername `
            -Filter "drivetype=3" |
        Sort-Object -Property DeviceID |
        Format-Table -Property DeviceID,
        @{label='FreeSpace(MB)';expression={$_.Freespace / 1MB -as [int]}},
        @{label='Size(GB)';expression={$_.Size / 1GB -as [int]}},
        @{Label='%Free';expression={$_.FreeSpace /$_.Size * 100 -as [int]}}