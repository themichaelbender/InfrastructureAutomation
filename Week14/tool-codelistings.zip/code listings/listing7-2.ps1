﻿function <name> {
    [CmdletBinding()]
    param(
        [string[]]$ComputerName,

        [string]$ErrorLog
    )
    BEGIN {}
    PROCESS {}
    END {}
}
