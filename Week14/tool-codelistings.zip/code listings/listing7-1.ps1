﻿function <name> {
    [CmdletBinding()]
    param(
    )
    BEGIN {}
    PROCESS {}
    END {}
}
